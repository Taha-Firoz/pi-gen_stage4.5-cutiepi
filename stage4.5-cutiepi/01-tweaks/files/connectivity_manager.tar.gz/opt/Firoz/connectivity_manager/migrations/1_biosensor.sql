CREATE TABLE biosensor (
    addr        TEXT NOT NULL,
    x           INTEGER(2) NOT NULL,
    y           INTEGER(2) NOT NULL,
    z           INTEGER(2) NOT NULL,
    tz  INTEGER(4) NOT NULL DEFAULT (strftime('%s','now'))
);
