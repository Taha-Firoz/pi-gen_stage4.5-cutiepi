CREATE TABLE scale (
    addr        TEXT NOT NULL,
    weight      REAL NOT NULL,
    impedance   INTEGER NOT NULL,
    unit        TEXT CHECK( unit IN ('KG','LB','CA') ) NOT NULL,
    created_on  INTEGER(4) NOT NULL DEFAULT (strftime('%s','now'))
);