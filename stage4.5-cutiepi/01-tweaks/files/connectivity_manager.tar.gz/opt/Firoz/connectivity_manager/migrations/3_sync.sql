CREATE TABLE sync (
    last_sync_from  INTEGER(4) NOT NULL DEFAULT (strftime('%s','now')),
    created_on      INTEGER(4) NOT NULL DEFAULT (strftime('%s','now'))
);