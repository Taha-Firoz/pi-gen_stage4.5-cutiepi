CREATE TABLE activity_schedule (
    schedule_id TEXT NOT NULL,
    -- SURVEY, FOLLOWUP, WEIGHIN, PROTOCOL, SYNC
    activity_type TEXT NOT NULL,
    -- any scheduled id that this depends on
    parent_id TEXT,

    initialized_on INTEGER NOT NULL,

    shown_on INTEGER,
      
    started_on INTEGER,  

    expired_on INTEGER,

    completed_on INTEGER,

    -- generic JSON column
    meta TEXT,

    PRIMARY KEY(schedule_id),
    FOREIGN KEY(parent_id) REFERENCES activity_schedule(schedule_id)
);

CREATE TABLE queued_messages (
    body BLOB NOT NULL,
    queued_on INTEGER NOT NULL
);
